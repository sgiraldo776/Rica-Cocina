<?php 
$conn = new mysqli('localhost','root','','rica_cocina');

$URL = "http://localhost/Rica-Cocina/";


?>